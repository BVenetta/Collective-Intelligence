from tabnanny import check
import matplotlib.pyplot as plt
import random
from pygame.math import Vector2
from vi import Agent, Simulation, probability
from vi.config import Config
import polars as pl
import seaborn as sns

class Fox(Agent):
    timer = 0
    energy = 5
    max_energy = 10
    reprod_prob = 0.5
    nr_foxes = 20


    def update(self): 
        if self.energy <= 0:
            self.kill()
            Fox.nr_foxes -= 1
        elif self.energy < self.max_energy: #hungry 
            self.eat()
        
        # energy decrease takes place every 60 frames (which is 1 second)
        if self.timer < 60: 
            self.timer += 1
        else:
            self.energy_decrease()
            self.timer = 0

        self.save_data("nr_rabbits", Rabbit.nr_rabbits)
        self.save_data("nr_foxes", Fox.nr_foxes)
        self.save_data("nr_grass", Grass.nr_grass)
        self.save_data("mean", (Rabbit.nr_rabbits+Fox.nr_foxes)/2)
        self.save_data("kind", 0)

    #if hungry check for food
    def eat(self):
        if self.in_proximity_accuracy().count() > 0:
            for agent, distance in self.in_proximity_accuracy():
                if isinstance(agent, Rabbit) and distance <= 15:
                    agent.kill()
                    self.replenish()
                    self.fox_reprod()
                    Rabbit.nr_rabbits -= 1

    def replenish(self):
        self.energy += 1

    def fox_reprod(self): #use to reproduce
        if probability(1/self.energy):
            self.reproduce()
            Fox.nr_foxes += 1
    
    def energy_decrease(self):
        self.energy -= 0.5

class Grass(Agent):
    timer = 0 
    fully_grown = True
    nr_grass = 15
       
    def update(self):
            
        if self.fully_grown == False:
            self.timer+=1
            if self.timer > 300:
                self.fully_grown = True
                self.change_image(0)
                self.timer=0
                Grass.nr_grass += 1
            
        self.save_data("nr_rabbits", Rabbit.nr_rabbits)
        self.save_data("nr_foxes", Fox.nr_foxes)
        self.save_data("nr_grass", Grass.nr_grass)
        self.save_data("mean", (Rabbit.nr_rabbits+Fox.nr_foxes)/2)
        self.save_data("kind", 2)

    def eaten(self):
        self.fully_grown = False
        self.change_image(1)
        Grass.nr_grass -= 1

    def on_spawn(self):
        self.pos = Vector2(random.uniform(50, 700),random.uniform(50, 700)) 
        self.freeze_movement()
          
class Rabbit(Agent):
    timer1 = 0
    timer2 = 0
    
    energy = 5
    max_energy = 10

    reprod_prob = 0.6
    nr_rabbits = 20

    def update(self):
        #check for reproduction every 5 seconds (300 frames)
        if self.timer1 < 300:
            self.timer1 += 1
        else:
            self.rabbit_reprod()
            self.timer1 = 0
        
        self.save_data("nr_rabbits", Rabbit.nr_rabbits)
        self.save_data("nr_foxes", Fox.nr_foxes)
        self.save_data("nr_grass", Grass.nr_grass)
        self.save_data("mean", (Rabbit.nr_rabbits+Fox.nr_foxes)/2)
        self.save_data("kind", 1)

        if self.energy <= 0:
            self.kill()
            Rabbit.nr_rabbits -= 1
        elif self.energy < self.max_energy: #hungry 
            self.eat()
            
        # energy decrease takes place every 60 frames (which is 1 second)
        if self.timer2 < 60: 
            self.timer2 += 1
        else:
            self.energy_decrease()
            self.timer2 = 0

    def rabbit_reprod(self): #use to reproduce
        if probability(self.reprod_prob):
            self.reproduce()
            Rabbit.nr_rabbits += 1

    def replenish(self):
        self.energy += 1
        
    def eat(self):
        if self.in_proximity_accuracy().count() > 0:
            for agent, distance in self.in_proximity_accuracy():
                if isinstance(agent, Grass) and distance <= 20:
                    if agent.fully_grown == True:
                        agent.eaten()
                        self.replenish()
                        self.rabbit_reprod()
    
    def energy_decrease(self):
        self.energy -= 0.5
    
x, y = Config().window.as_tuple() 
df=(
    Simulation(Config(radius=30, movement_speed=1.5, seed=1, duration=400*60))
    .batch_spawn_agents(   
        20,
        Rabbit,  # 👈 use our own MyAgent class
        images=["images/rabbit_face.png"],
        
    )
    .batch_spawn_agents(
        20,
        Fox,  # 👈 use our own MyAgent class
        images=["images/fox_face.png"],
    )
    .batch_spawn_agents(
        10,
        Grass,  # 👈 use our own MyAgent class
        images=["images/grass.png", "images/grass_eaten.png"],    
    )
    .run()
    .snapshots.rechunk()
    .groupby(['frame', 'nr_foxes', 'nr_rabbits'])
    .agg(pl.count("id").alias('agents'))
    .sort(['frame'])
)

# df["agents"] = df["agents"]-15 #subtract number of grass agents because we do not regard them as "agents"
# df = df[df.kind != 2]

# print(df)

# plot = sns.relplot(x=df["frame"], y=df["agents"], hue=df["kind"],kind="line",legend=False)
# plt.legend(labels=["Foxes", "Rabbits"], title="Population sizes", loc = 2, bbox_to_anchor = (1,1))
# plot.savefig('convergence5.png', dpi=300)

df = df.to_pandas()
# df.to_csv('grass.csv')
# sns.boxplot(y = df['frame'], x = df['nr_rabbits'])
# plt.show()

# ax = plt.gca() 

# df.plot(kind = 'line',x = 'frame', y = 'mean', color = 'purple',ax = ax, xlabel = "frame", ylabel = "agents")
# plt.show()
ax = plt.gca() 
df.plot(kind = 'line',x = 'frame', y = 'nr_rabbits', color = 'orange',ax = ax)
df.plot(kind = 'line',x = 'frame', y = 'nr_foxes', color = 'blue',ax = ax)
plt.legend(labels=["Foxes", "Rabbits"], title="Population sizes")
plt.xticks([0, 2500, 5000, 7500, 10000, 12500, 15000, 17500, 20000, 22500, 25000])
plt.xlim(right=25000)
plt.yticks([10, 20, 30, 40, 50, 60, 70, 80, 90, 100])
plt.ylabel('agents')
plt.title('Energy-Based model')
plt.show()
df.plot() 