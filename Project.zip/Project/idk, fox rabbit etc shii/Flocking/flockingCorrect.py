from enum import Enum, auto

import pygame as pg
from pygame.math import Vector2
from vi import Agent, Simulation
from vi.config import Config, dataclass, deserialize

from random import uniform

@deserialize
@dataclass
class FlockingConfig(Config):
    alignment_weight: float = 2
    cohesion_weight: float = 4.5
    separation_weight: float = 4

    # weight for randomness
    randomWeight: float = 0.5

    # maximum velocity
    maxVelocity = 5

    delta_time: float = 3

    mass: int = 20

    def weights(self) -> tuple[float, float, float, float]:
        return (self.alignment_weight, self.cohesion_weight, self.separation_weight, self.randomWeight)


class Bird(Agent):
    config: FlockingConfig

    def change_position(self):
        # Pac-man-style teleport to the other end of the screen when trying to escape
        self.there_is_no_escape()
        
        alignmentWeight, separationWeight, cohesionWeight, randomWeight = self.config.weights()
        inProximity = list(self.in_proximity_accuracy())

        if len(inProximity) == 0:
            pass

        else:
            totalVeocity = Vector2()
            totalDifference = Vector2()
            totalPosition = Vector2()

            for boid, distance in inProximity:
                totalVeocity += boid.move
                totalDifference += (self.pos - boid.pos)
                totalPosition += boid.pos

            averageVelocity = totalVeocity/len(inProximity)
            averageDifference = totalDifference/len(inProximity)
            averagePosition = totalPosition/len(inProximity)
            cohesionForce = averagePosition - self.pos

            alignment = (averageVelocity - self.move).normalize()
            separation = averageDifference.normalize()
            cohesion = (cohesionForce - self.move).normalize()

            randomNoise = Vector2(uniform(-1,1), uniform(-1,1))

            totalForce = (alignmentWeight*alignment + separationWeight*separation + cohesionWeight*cohesion + randomWeight*randomNoise)/self.config.mass

            self.move += totalForce

        if self.move.length() < self.config.maxVelocity:
            self.move.normalize() * self.config.maxVelocity

        self.pos += self.move * self.config.delta_time



class Selection(Enum):
    ALIGNMENT = auto()
    COHESION = auto()
    SEPARATION = auto()


class FlockingLive(Simulation):
    selection: Selection = Selection.ALIGNMENT
    config: FlockingConfig

    def handle_event(self, by: float):
        if self.selection == Selection.ALIGNMENT:
            self.config.alignment_weight += by
        elif self.selection == Selection.COHESION:
            self.config.cohesion_weight += by
        elif self.selection == Selection.SEPARATION:
            self.config.separation_weight += by

    def before_update(self):
        super().before_update()

        for event in pg.event.get():
            if event.type == pg.KEYDOWN:
                if event.key == pg.K_UP:
                    self.handle_event(by=0.1)
                elif event.key == pg.K_DOWN:
                    self.handle_event(by=-0.1)
                elif event.key == pg.K_1:
                    self.selection = Selection.ALIGNMENT
                elif event.key == pg.K_2:
                    self.selection = Selection.COHESION
                elif event.key == pg.K_3:
                    self.selection = Selection.SEPARATION

        a, c, s, r = self.config.weights()
        print(f"A: {a:.1f} - C: {c:.1f} - S: {s:.1f} - R: {r:.1f}")


(
    FlockingLive(
        FlockingConfig(
            image_rotation=True,
            movement_speed=2,
            radius=50,
            seed=1,
            fps_limit = 60
        )
    )
    .batch_spawn_agents(50, Bird, images=["images/white.png"])
    .run()
    .snapshots
)
