from tabnanny import check
import pygame 
import random
from pygame.math import Vector2
from vi import Agent, Simulation, probability
from vi.config import Config
import polars as pl
import seaborn as sns

class Fox(Agent):

    timer = 0
    energy = 40
    max_energy = 60

    reprod_prob = 0.1
    nr_foxes = 25

    def update(self): 
        #check energy level, if <=0, kill
        if self.energy <= 0:
            self.kill()
            Fox.nr_foxes -= 1
        elif self.energy < self.max_energy: #hungry 
            self.eat()
        
        # energy decrease takes place every 60 frames (which is 1 second)
        if self.timer < 60: 
            self.timer += 1
        else:
            self.energy_decrease()
            self.timer = 0

        self.save_data("nr_rabbits", Rabbit.nr_rabbits)
        self.save_data("nr_foxes", Fox.nr_foxes)

    #if hungry check for food
    def eat(self):
        if self.in_proximity_accuracy().count() > 0:
            for agent, distance in self.in_proximity_accuracy():
                if isinstance(agent, Rabbit):
                    agent.kill()
                    self.replenish()
                    self.fox_reprod()
                    Rabbit.nr_rabbits -= 1

    def replenish(self):
        self.energy += 2

    def fox_reprod(self): #use to reproduce
        if probability(self.reprod_prob):
            self.reproduce()
            Fox.nr_foxes += 1
        # else:
        #     self.hungry_check()
    
    def energy_decrease(self):
        self.energy -= 0.5

class Rabbit(Agent):

    timer = 0
    energy = 25 #for extras

    reprod_prob = 0.4
    nr_rabbits = 15

    def update(self):
        #check for reproduction every 5 seconds (300 frames)
        if self.timer < 300:
            self.timer += 1
        else:
            self.rabbit_reprod()
            self.timer = 0
        
        self.save_data("nr_rabbits", Rabbit.nr_rabbits)
        self.save_data("nr_foxes", Fox.nr_foxes)

    def rabbit_reprod(self): #use to reproduce
        if probability(self.reprod_prob):
            self.reproduce()
            Rabbit.nr_rabbits += 1
        

x, y = Config().window.as_tuple() 

df=(
    Simulation(Config(radius=15))
    .batch_spawn_agents(
        15,
        Rabbit,  # 👈 use our own MyAgent class
        images=["images/rabbit_face.png"],
    )
    .batch_spawn_agents(
        25,
        Fox,  # 👈 use our own MyAgent class
        images=["images/fox_face.png"],
    )
    .run()
    .snapshots
    .groupby(['frame', 'nr_rabbits', 'nr_foxes'])
    .agg(pl.count("id").alias('agents'))
    .sort(['frame'])
)

print(df)
dfm = df.melt(id_vars=['frame', 'agents'], value_vars=['nr_rabbits', 'nr_foxes'], variable_name='type', value_name='nr')
print(dfm)
# plot = sns.relplot(x=dfm['frame'], y=dfm['agents'], hue=['type'], kind='line')
plot = sns.relplot(data=dfm, x="frame", y="agents", hue="type",kind="line")
plot.savefig('plot.png', dpi=300)