from turtle import color
import pandas as pd
import matplotlib.pyplot as plt


# df = pd.read_csv('basic.csv', header=0)

# print(df.iloc[:,[1,2]].describe())

# ax = plt.gca() 
# df.plot(kind = 'line',x = 'frame', y = 'nr_rabbits', color = 'orange',ax = ax)
# df.plot(kind = 'line',x = 'frame', y = 'nr_foxes', color = 'blue',ax = ax)
# plt.legend(labels=["Foxes", "Rabbits"], title="Population sizes")
# plt.xticks([0, 2500, 5000, 7500, 10000, 12500, 15000, 17500])
# plt.xlim(right=18500)
# plt.yticks([10, 20, 30, 40, 50, 60, 70, 80, 90, 100])
# plt.ylabel('agents')
# plt.title('Basic model')
# plt.show()
# df.plot()

import numpy as np

x = np.array(['Basic', 'Energy-Based', 'Flocking'])
yf = np.array([40.28269, 8.818537, 31.07191]) # Effectively y = x**2
ef = np.array([25.9954, 4.52855, 22.26978])
yr = np.array([62.74728, 27.64651, 17.87613]) # Effectively y = x**2
er = np.array([77.65151, 11.16687, 16.84535])

plt.errorbar(x, yr, er, linestyle='--', marker='o', mfc='blue')
plt.errorbar(x, yf, ef, linestyle='--', marker='o', mfc='red')
plt.ylabel('agents')
plt.title('Mean plot of Population size')
plt.legend(labels=["Rabbits", "Foxes"], title="Species")
plt.show()


