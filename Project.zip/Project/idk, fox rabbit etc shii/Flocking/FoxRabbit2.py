from tabnanny import check
from numpy import fix
import matplotlib.pyplot as plt
import random
from pygame.math import Vector2
from vi import Agent, Simulation, probability, Window
from vi.config import Config
import polars as pl
import seaborn as sns

class Fox(Agent):

    timer = 0
    energy = 20
    max_energy = 15

    reprod_prob = 0.1
    nr_foxes = 20
    eaten = 0

    def update(self): 
        #check energy level, if <=0, kill
        if self.energy <= 0:
            self.kill()
            Fox.nr_foxes -= 1
        elif self.energy < self.max_energy: #hungry 
            self.eat()
        
        # energy decrease takes place every 60 frames (which is 1 second)
        if self.timer < 60: 
            self.timer += 1
        else:
            self.energy_decrease()
            self.timer = 0

        # if Fox.nr_foxes > 1.5*Rabbit.nr_rabbits:
        #     Fox.reprod_prob = 0.1
        # if Fox.nr_foxes <= Rabbit.nr_rabbits:
        #     Fox.reprod_prob = 0.5

        self.save_data("nr_rabbits", Rabbit.nr_rabbits)
        self.save_data("nr_foxes", Fox.nr_foxes)
        self.save_data("kind", 0)

    #if hungry check for food
    def eat(self):
        if self.in_proximity_accuracy().count() > 0:
            for agent, distance in self.in_proximity_accuracy():
                if isinstance(agent, Rabbit):
                    agent.kill()
                    self.eaten += 1
                    self.replenish()
                    self.fox_reprod()
                    Rabbit.nr_rabbits -= 1
                    print(1-1/self.energy)
                    
    def replenish(self):
        self.energy += 0.25

    def fox_reprod(self): #use to reproduce
        if probability(1/self.energy) and self.energy < 10:
            self.reproduce()
            Fox.nr_foxes += 1

    def energy_decrease(self):
        self.energy -= 1

class Rabbit(Agent):

    timer = 0
    energy = 20 #for extras
#0.39
    reprod_prob = 0.5
    nr_rabbits = 20

    def update(self):
        #check for reproduction every 5 seconds (300 frames)
        if self.timer < 300:
            self.timer += 1
        else:
            self.rabbit_reprod()
            self.timer = 0

        # if Rabbit.nr_rabbits > 2*Fox.nr_foxes:
        #     Rabbit.reprod_prob = 0.1
        # if Rabbit.nr_rabbits < Fox.nr_foxes:
        #     Rabbit.reprod_prob = 0.5

        self.save_data("nr_rabbits", Rabbit.nr_rabbits)
        self.save_data("nr_foxes", Fox.nr_foxes)
        self.save_data("kind", 1)

    def rabbit_reprod(self): #use to reproduce
        if probability(self.reprod_prob):
            self.reproduce()
            Rabbit.nr_rabbits += 1
        

x, y = Config().window.as_tuple() 

df=(
    Simulation(Config(radius=15, movement_speed=1.5, window=Window.square(600)))
    .batch_spawn_agents(
        20,
        Rabbit,  # 👈 use our own MyAgent class
        images=["images/rabbit_face.png"],
    )
    .batch_spawn_agents(
        20,
        Fox,  # 👈 use our own MyAgent class
        images=["images/fox_face.png"],
    )
    .run()
    .snapshots.rechunk()
    #.groupby(['frame', 'nr_rabbits', 'nr_foxes'])
    .groupby(['frame', 'kind'])
    .agg(pl.count("id").alias('agents'))
    .sort(['frame', 'kind'])
)

print(df)

plot = sns.relplot(x=df["frame"], y=df["agents"], hue=df["kind"],kind="line",legend=False)
plt.legend(labels=["Foxes", "Rabbits"], title="Population sizes", loc = 2, bbox_to_anchor = (1,1))
plot.savefig('plot6.png', dpi=300)