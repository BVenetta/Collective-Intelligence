from itertools import groupby
import random, math
import time
from tkinter import Frame
import numpy as np
from cmath import exp
import polars as pl
from vi import Agent, Config, Simulation, probability
import seaborn as sns
import matplotlib.pyplot as plt

def stable_sigmoid(x):

    if x >= 0:
        z = math.exp(-x)
        sig = 1 / (1 + z)
        return sig
    else:
        z = math.exp(x)
        sig = z / (1 + z)
        return sig

class Cockroach(Agent):
    
    timer = 0
    state = 'wander'
    
    def update(self):
        #Wandering
        #Join
        #Still
        #Leave
    
        if self.state == 'wander':
            # self.change_image(0)
            self.wandering()
        elif self.state == 'join':
            self.join()
        elif self.state == 'still':
            self.still()
        elif self.state == 'leave':
            # self.change_image(2)
            self.leave()

        if self.timer <= 30 and self.on_site():
            self.timer += 1
        else:
            self.timer = 0
        
    
    def wandering(self):
        #p_join = random.uniform(0, 1) * self.in_proximity_accuracy().count()
        p_join = 0.03 + 0.48 * (1-math.e**(-1.70188*self.in_proximity_accuracy().count())) 
        #p_join = stable_sigmoid(self.in_proximity_accuracy().count())
        if self.on_site() and probability(p_join):
            self.state = 'join' 

    def join(self):
        if self.on_site() == True:
            if self.timer == 30:
                self.freeze_movement()
                self.timer = 0
                self.state = 'still'
                # if self.pos.x < 375:
                #     self.change_image(1)
                # else:
                #     self.change_image(2)

    def still(self):
        p_leave = math.e**(-3.88785*self.in_proximity_accuracy().count())
       # p_leave = 1 - stable_sigmoid(self.in_proximity_accuracy().count())
        if probability(p_leave):
            self.state = 'leave'

    def leave(self):
        self.continue_movement()
        if self.on_site() == False:
            self.state = 'wander'

x, y = Config().window.as_tuple() 
df=(
    Simulation(Config(radius=50, movement_speed=2.5))
    .spawn_site("images/small2.png", x // 4, y // 2)
    .spawn_site("images/small2.png", x-(x // 4), y // 2)
    .spawn_obstacle("images/Untitled.png", (x // 2)-5, y // 2)
    .batch_spawn_agents(
        100,
        Cockroach,  # 👈 use our own MyAgent class
        images=["images/red.png"],
    )
    .run()
    .snapshots
    .groupby(['frame', 'image_index'])
    .agg(pl.count("id").alias('agents'))
    .sort(['frame', 'image_index'])
)

print(df)
#plot = sns.relplot(x=df['frame'], y=df['agents'], hue=df["image_index"])
plot = sns.relplot(x=df['frame'], y=df['agents'], hue=df["image_index"], kind='line')
plt.legend(title='Sites', loc='upper right', labels=['Not on site', 'Left site', 'Right site'])
plot.savefig('convergence2.png', dpi=300)